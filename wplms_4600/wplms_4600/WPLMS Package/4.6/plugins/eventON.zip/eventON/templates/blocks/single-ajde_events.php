<?php

?>
<!-- wp:template-part {"slug":"header","tagName":"header"} /-->
<!-- wp:group {"layout":{"inherit":true}} -->

<!-- wp:pattern {"slug" : "eventon/single-ajde_events"} /-->
<!-- wp:eventon/single-ajde_events /-->
<!-- /wp:group -->
<!-- wp:template-part {"slug":"footer","tagName":"footer"} /-->